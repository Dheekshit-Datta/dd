import { ArrowLeft } from "lucide-react"
import Link from "next/link"

import { Button } from "@/components/ui/button"

export default function DemoPage() {
  return (
    <main className="min-h-screen bg-gray-50 dark:bg-gray-900 p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        <div className="mb-6">
          <Button variant="ghost" size="sm" asChild>
            <Link
              href="/"
              className="flex items-center gap-1 text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
            >
              <ArrowLeft className="h-4 w-4" />
              Back to Home
            </Link>
          </Button>
        </div>

        <div className="rounded-xl overflow-hidden border border-purple-500/20 shadow-xl shadow-purple-500/5 backdrop-blur-sm bg-white dark:bg-gray-800 p-8">
          <h1 className="text-3xl font-bold mb-6 text-center">Smart Notes App Demo</h1>

          <div className="aspect-video rounded-lg overflow-hidden border border-purple-200 dark:border-purple-800 flex items-center justify-center bg-gray-100 dark:bg-gray-900">
            <div className="text-center p-8">
              <p className="text-gray-500 dark:text-gray-400 mb-4">Demo video will be displayed here</p>
              <Button className="bg-purple-600 hover:bg-purple-700">Play Demo</Button>
            </div>
          </div>
        </div>
      </div>
    </main>
  )
}
