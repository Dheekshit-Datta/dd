"use client"

import type { ReactNode } from "react"
import { motion } from "framer-motion"

interface FeatureSectionProps {
  icon: ReactNode
  title: string
  description: string
}

export default function FeatureSection({ icon, title, description }: FeatureSectionProps) {
  return (
    <motion.div
      whileHover={{ scale: 1.05, rotate: 1 }}
      className="group relative p-8 rounded-[1.5rem] border-2 border-purple-500/10 bg-white/5 backdrop-blur-sm hover:bg-purple-500/5 transition-all duration-300 hover:shadow-xl hover:shadow-purple-500/10"
    >
      <div className="absolute inset-0 rounded-[1.5rem] bg-gradient-to-r from-purple-500/5 via-pink-500/5 to-indigo-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>

      <div className="relative z-10">
        <motion.div
          whileHover={{ rotate: [0, -10, 10, -10, 0] }}
          transition={{ duration: 0.5 }}
          className="mb-6 p-4 rounded-2xl inline-block bg-gradient-to-r from-purple-500/10 via-pink-500/10 to-indigo-500/10 group-hover:from-purple-500/20 group-hover:via-pink-500/20 group-hover:to-indigo-500/20 transition-colors duration-300"
        >
          <div className="text-3xl">{icon}</div>
        </motion.div>

        <h3 className="text-2xl font-bold mb-3 text-transparent bg-clip-text bg-gradient-to-r from-purple-500 to-pink-500 group-hover:from-purple-400 group-hover:to-pink-400 transition-colors duration-300">
          {title}
        </h3>

        <p className="text-gray-500 dark:text-gray-400 text-lg">{description}</p>
      </div>
    </motion.div>
  )
}
