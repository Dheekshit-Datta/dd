"use client"

import { useEffect, useState } from "react"
import { motion } from "framer-motion"
import { Brain, FileText, Search, Tag, Sparkles, Lightbulb, Zap, MessageSquare, LinkIcon } from "lucide-react"
import type { JSX } from "react"

export function FloatingIcons() {
  const [icons, setIcons] = useState<JSX.Element[]>([])

  useEffect(() => {
    const iconComponents = [
      <Brain key="brain" className="text-purple-400" />,
      <FileText key="file" className="text-indigo-400" />,
      <Search key="search" className="text-blue-400" />,
      <Tag key="tag" className="text-pink-400" />,
      <Sparkles key="sparkles" className="text-amber-400" />,
      <Lightbulb key="lightbulb" className="text-yellow-400" />,
      <Zap key="zap" className="text-orange-400" />,
      <MessageSquare key="message" className="text-green-400" />,
      <LinkIcon key="link" className="text-cyan-400" />,
    ]

    const floatingIcons = iconComponents.map((icon, index) => {
      const size = Math.random() * 16 + 24 // Random size between 24px and 40px
      const x = Math.random() * 100 - 50 // Random x position
      const y = Math.random() * 100 - 50 // Random y position
      const duration = Math.random() * 20 + 10 // Random duration between 10s and 30s
      const delay = Math.random() * 5 // Random delay

      return (
        <motion.div
          key={index}
          initial={{
            x,
            y,
            opacity: 0,
            scale: 0,
          }}
          animate={{
            x: [x, x + 20, x - 20, x],
            y: [y, y - 20, y + 20, y],
            opacity: [0, 0.7, 0.5, 0.7, 0],
            scale: [0, 1, 0.8, 1, 0],
          }}
          transition={{
            repeat: Number.POSITIVE_INFINITY,
            duration,
            delay,
            times: [0, 0.25, 0.5, 0.75, 1],
          }}
          className="absolute"
          style={{ width: size, height: size }}
        >
          {icon}
        </motion.div>
      )
    })

    setIcons(floatingIcons)
  }, [])

  return <div className="absolute inset-0 overflow-hidden">{icons}</div>
}
