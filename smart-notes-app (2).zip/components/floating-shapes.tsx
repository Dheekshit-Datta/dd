"use client"

import { useEffect, useState } from "react"
import { motion } from "framer-motion"

interface Shape {
  id: number
  x: number
  y: number
  size: number
  rotation: number
  color: string
  type: "circle" | "square" | "triangle" | "hexagon"
  duration: number
  delay: number
}

export function FloatingShapes() {
  const [shapes, setShapes] = useState<Shape[]>([])

  useEffect(() => {
    const colors = ["bg-purple-500/10", "bg-pink-500/10", "bg-indigo-500/10", "bg-blue-500/10", "bg-cyan-500/10"]

    const types: ("circle" | "square" | "triangle" | "hexagon")[] = ["circle", "square", "triangle", "hexagon"]

    const newShapes: Shape[] = Array.from({ length: 15 }).map((_, index) => ({
      id: index,
      x: Math.random() * 100,
      y: Math.random() * 100,
      size: Math.random() * 100 + 50,
      rotation: Math.random() * 360,
      color: colors[Math.floor(Math.random() * colors.length)],
      type: types[Math.floor(Math.random() * types.length)],
      duration: Math.random() * 50 + 30,
      delay: Math.random() * 10,
    }))

    setShapes(newShapes)
  }, [])

  const renderShape = (shape: Shape) => {
    switch (shape.type) {
      case "circle":
        return (
          <div
            className={`rounded-full ${shape.color} backdrop-blur-3xl border border-white/10`}
            style={{ width: shape.size, height: shape.size }}
          />
        )
      case "square":
        return (
          <div
            className={`rounded-lg ${shape.color} backdrop-blur-3xl border border-white/10`}
            style={{ width: shape.size, height: shape.size }}
          />
        )
      case "triangle":
        return (
          <div
            className={`${shape.color} backdrop-blur-3xl border border-white/10`}
            style={{
              width: shape.size,
              height: shape.size,
              clipPath: "polygon(50% 0%, 0% 100%, 100% 100%)",
            }}
          />
        )
      case "hexagon":
        return (
          <div
            className={`${shape.color} backdrop-blur-3xl border border-white/10`}
            style={{
              width: shape.size,
              height: shape.size,
              clipPath: "polygon(25% 0%, 75% 0%, 100% 50%, 75% 100%, 25% 100%, 0% 50%)",
            }}
          />
        )
    }
  }

  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
      {shapes.map((shape) => (
        <motion.div
          key={shape.id}
          initial={{
            x: `${shape.x}vw`,
            y: `${shape.y}vh`,
            rotate: shape.rotation,
            opacity: 0,
          }}
          animate={{
            x: [`${shape.x}vw`, `${shape.x + 10}vw`, `${shape.x - 5}vw`, `${shape.x}vw`],
            y: [`${shape.y}vh`, `${shape.y - 10}vh`, `${shape.y + 5}vh`, `${shape.y}vh`],
            rotate: [shape.rotation, shape.rotation + 20, shape.rotation - 20, shape.rotation],
            opacity: [0, 0.5, 0.3, 0],
          }}
          transition={{
            repeat: Number.POSITIVE_INFINITY,
            duration: shape.duration,
            delay: shape.delay,
            ease: "linear",
          }}
          className="absolute"
        >
          {renderShape(shape)}
        </motion.div>
      ))}
    </div>
  )
}
