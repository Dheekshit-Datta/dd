"use client"

import type { ReactNode } from "react"
import { motion } from "framer-motion"

export function GlowingText({ children }: { children: ReactNode }) {
  return (
    <div className="relative inline-block">
      <motion.span
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1 }}
        className="relative z-10 bg-clip-text text-transparent bg-gradient-to-r from-purple-600 via-pink-500 to-indigo-500"
      >
        {children}
      </motion.span>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 0.6 }}
        transition={{ duration: 1, delay: 0.5 }}
        className="absolute inset-0 blur-2xl bg-gradient-to-r from-purple-600/20 via-pink-500/20 to-indigo-500/20 z-0"
      ></motion.div>
    </div>
  )
}
