"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Edit, MoreHorizontal, Trash, Sparkles } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

interface Note {
  id: number
  title: string
  content: string
  category: string
  tags: string[]
  date: string
}

interface NoteCardProps {
  note: Note
}

export function NoteCard({ note }: NoteCardProps) {
  const [isHovered, setIsHovered] = useState(false)

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "Work":
        return "bg-blue-500"
      case "Personal":
        return "bg-green-500"
      case "Ideas":
        return "bg-purple-500"
      case "Research":
        return "bg-amber-500"
      case "Projects":
        return "bg-pink-500"
      default:
        return "bg-gray-500"
    }
  }

  const getCategoryGradient = (category: string) => {
    switch (category) {
      case "Work":
        return "from-blue-500 to-indigo-500"
      case "Personal":
        return "from-green-500 to-emerald-500"
      case "Ideas":
        return "from-purple-500 to-pink-500"
      case "Research":
        return "from-amber-500 to-orange-500"
      case "Projects":
        return "from-pink-500 to-rose-500"
      default:
        return "from-gray-500 to-slate-500"
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      whileHover={{ y: -8, rotate: 1 }}
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
    >
      <Card className="overflow-hidden border-2 border-purple-100 dark:border-gray-700 transition-all duration-300 hover:shadow-xl hover:shadow-purple-500/10 group rounded-[1.2rem]">
        <CardHeader className="p-5 pb-0 flex flex-row items-start justify-between relative">
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r ${getCategoryGradient(note.category)}"></div>
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className={`w-3 h-3 rounded-full ${getCategoryColor(note.category)}`}></span>
              <span className="text-xs font-medium text-transparent bg-clip-text bg-gradient-to-r ${getCategoryGradient(note.category)}">
                {note.category}
              </span>
            </div>
            <h3 className="font-bold text-xl text-gray-900 dark:text-white group-hover:text-transparent group-hover:bg-clip-text group-hover:bg-gradient-to-r group-hover:from-purple-500 group-hover:to-pink-500 transition-colors">
              {note.title}
            </h3>
          </div>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
                <MoreHorizontal className="h-4 w-4" />
                <span className="sr-only">Open menu</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="rounded-xl border-purple-100 dark:border-gray-700">
              <DropdownMenuItem className="rounded-lg cursor-pointer">
                <Edit className="mr-2 h-4 w-4" />
                <span>Edit</span>
              </DropdownMenuItem>
              <DropdownMenuItem className="text-red-600 dark:text-red-400 rounded-lg cursor-pointer">
                <Trash className="mr-2 h-4 w-4" />
                <span>Delete</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </CardHeader>

        <CardContent className="p-5">
          <p className="text-gray-600 dark:text-gray-300 text-sm line-clamp-3">{note.content}</p>
        </CardContent>

        <CardFooter className="p-5 pt-0 flex flex-col items-start">
          <div className="flex flex-wrap gap-1.5 mb-2">
            {note.tags.map((tag) => (
              <motion.span
                key={tag}
                whileHover={{ scale: 1.1 }}
                className="px-2 py-0.5 text-xs rounded-full bg-gradient-to-r from-purple-100 to-pink-100 dark:from-purple-900/30 dark:to-pink-900/30 text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-pink-600 dark:from-purple-400 dark:to-pink-400 border border-purple-200 dark:border-purple-800/30"
              >
                #{tag}
              </motion.span>
            ))}
          </div>
          <span className="text-xs text-gray-400 flex items-center gap-1">
            <Sparkles className="h-3 w-3 text-purple-400" />
            {note.date}
          </span>
        </CardFooter>
      </Card>
    </motion.div>
  )
}
