"use client"

import { useEffect, useRef } from "react"
import { motion } from "framer-motion"
import ForceGraph2D from "react-force-graph-2d"

interface Note {
  id: number
  title: string
  content: string
  category: string
  tags: string[]
  date: string
}

interface NoteGraphProps {
  notes: Note[]
}

export function NoteGraph({ notes }: NoteGraphProps) {
  const containerRef = useRef<HTMLDivElement>(null)

  // Create graph data from notes
  const graphData = {
    nodes: [
      ...notes.map((note) => ({
        id: `note-${note.id}`,
        name: note.title,
        val: 20,
        color: getCategoryColor(note.category),
        type: "note",
      })),
      ...Array.from(new Set(notes.flatMap((note) => note.tags))).map((tag) => ({
        id: `tag-${tag}`,
        name: tag,
        val: 10,
        color: "#9333ea", // Purple for tags
        type: "tag",
      })),
    ],
    links: [
      // Connect notes to their tags
      ...notes.flatMap((note) =>
        note.tags.map((tag) => ({
          source: `note-${note.id}`,
          target: `tag-${tag}`,
          value: 1,
        })),
      ),
      // Connect notes with similar tags
      ...notes.flatMap((note1) =>
        notes
          .filter((note2) => note1.id !== note2.id && note1.tags.some((tag) => note2.tags.includes(tag)))
          .map((note2) => ({
            source: `note-${note1.id}`,
            target: `note-${note2.id}`,
            value: 0.5,
          })),
      ),
    ],
  }

  function getCategoryColor(category: string): string {
    switch (category) {
      case "Work":
        return "#3b82f6" // blue-500
      case "Personal":
        return "#22c55e" // green-500
      case "Ideas":
        return "#8b5cf6" // purple-500
      case "Research":
        return "#f59e0b" // amber-500
      case "Projects":
        return "#ec4899" // pink-500
      default:
        return "#6b7280" // gray-500
    }
  }

  useEffect(() => {
    const handleResize = () => {
      if (containerRef.current) {
        const width = containerRef.current.clientWidth
        const height = 400 // Fixed height or calculate based on container
        containerRef.current.style.width = `${width}px`
        containerRef.current.style.height = `${height}px`
      }
    }

    handleResize()
    window.addEventListener("resize", handleResize)

    return () => {
      window.removeEventListener("resize", handleResize)
    }
  }, [])

  return (
    <motion.div
      ref={containerRef}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="w-full h-[400px] relative"
    >
      <ForceGraph2D
        graphData={graphData}
        nodeLabel="name"
        nodeColor="color"
        nodeRelSize={6}
        linkWidth={1}
        linkColor={() => "#9333ea33"} // Semi-transparent purple
        backgroundColor="transparent"
        nodeCanvasObject={(node, ctx, globalScale) => {
          const label = node.name as string
          const fontSize = 12 / globalScale
          ctx.font = `${fontSize}px Sans-Serif`
          const textWidth = ctx.measureText(label).width
          const bckgDimensions = [textWidth, fontSize].map((n) => n + fontSize * 0.8)

          // Node circle
          ctx.beginPath()
          ctx.arc(node.x as number, node.y as number, (node.val as number) / 2, 0, 2 * Math.PI)
          ctx.fillStyle = node.color as string
          ctx.fill()

          // Text background
          ctx.fillStyle = "rgba(255, 255, 255, 0.8)"
          ctx.fillRect(
            (node.x as number) - bckgDimensions[0] / 2,
            (((node.y as number) + node.val) as number) / 2 + 2,
            bckgDimensions[0],
            bckgDimensions[1],
          )

          // Text
          ctx.textAlign = "center"
          ctx.textBaseline = "middle"
          ctx.fillStyle = "#333333"
          ctx.fillText(
            label,
            node.x as number,
            (((node.y as number) + node.val) as number) / 2 + 2 + bckgDimensions[1] / 2,
          )
        }}
      />
    </motion.div>
  )
}
