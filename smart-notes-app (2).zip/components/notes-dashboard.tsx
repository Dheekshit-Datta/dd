"use client"

import { useEffect, useRef, useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Brain, FileText, Search, X, Sparkles, Zap } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { NoteCard } from "@/components/note-card"
import { NoteGraph } from "@/components/note-graph"

const CATEGORIES = [
  { name: "Work", color: "bg-blue-500", gradient: "from-blue-500 to-indigo-500" },
  { name: "Personal", color: "bg-green-500", gradient: "from-green-500 to-emerald-500" },
  { name: "Ideas", color: "bg-purple-500", gradient: "from-purple-500 to-pink-500" },
  { name: "Research", color: "bg-amber-500", gradient: "from-amber-500 to-orange-500" },
  { name: "Projects", color: "bg-pink-500", gradient: "from-pink-500 to-rose-500" },
]

const SAMPLE_NOTES = [
  {
    id: 1,
    title: "Project Roadmap",
    content: "Define key milestones for Q3 and assign team responsibilities...",
    category: "Work",
    tags: ["planning", "team", "goals"],
    date: "2 days ago",
  },
  {
    id: 2,
    title: "Research on AI Trends",
    content: "Latest developments in generative AI and potential applications...",
    category: "Research",
    tags: ["ai", "technology", "trends"],
    date: "5 days ago",
  },
  {
    id: 3,
    title: "App Feature Ideas",
    content: "New features for the smart notes app: collaborative editing...",
    category: "Ideas",
    tags: ["features", "product", "innovation"],
    date: "1 week ago",
  },
  {
    id: 4,
    title: "Meeting Notes: Design Team",
    content: "Discussion about the new UI components and design system...",
    category: "Work",
    tags: ["meeting", "design", "ui"],
    date: "3 days ago",
  },
]

export default function NotesDashboard() {
  const [searchQuery, setSearchQuery] = useState("")
  const [activeView, setActiveView] = useState<"list" | "graph">("list")
  const [isSearching, setIsSearching] = useState(false)
  const [searchResults, setSearchResults] = useState(SAMPLE_NOTES)
  const [suggestedTags, setSuggestedTags] = useState<string[]>([])
  const searchInputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    if (searchQuery.length > 0) {
      setIsSearching(true)
      // Simulate search delay
      const timer = setTimeout(() => {
        const results = SAMPLE_NOTES.filter(
          (note) =>
            note.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
            note.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
            note.tags.some((tag) => tag.toLowerCase().includes(searchQuery.toLowerCase())),
        )
        setSearchResults(results)
        setIsSearching(false)

        // Simulate AI suggesting tags based on search
        if (searchQuery.length > 2) {
          const relatedTags = ["notes", "important", "follow-up", "review"]
          setSuggestedTags(relatedTags.filter((tag) => !searchQuery.includes(tag)))
        } else {
          setSuggestedTags([])
        }
      }, 500)

      return () => clearTimeout(timer)
    } else {
      setSearchResults(SAMPLE_NOTES)
      setSuggestedTags([])
      setIsSearching(false)
    }
  }, [searchQuery])

  const handleTagClick = (tag: string) => {
    setSearchQuery((prev) => (prev ? `${prev} ${tag}` : tag))
    searchInputRef.current?.focus()
  }

  return (
    <div className="bg-gray-50 dark:bg-gray-900 p-6 min-h-[600px]">
      <div className="flex flex-col h-full">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-3xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-pink-600">
            Your Smart Notes
          </h2>

          <div className="flex items-center gap-2">
            <Button
              variant={activeView === "list" ? "default" : "outline"}
              size="sm"
              onClick={() => setActiveView("list")}
              className={
                activeView === "list"
                  ? "bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 rounded-full"
                  : "rounded-full"
              }
            >
              <FileText className="h-4 w-4 mr-1" />
              List
            </Button>
            <Button
              variant={activeView === "graph" ? "default" : "outline"}
              size="sm"
              onClick={() => setActiveView("graph")}
              className={
                activeView === "graph"
                  ? "bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 rounded-full"
                  : "rounded-full"
              }
            >
              <Brain className="h-4 w-4 mr-1" />
              Graph
            </Button>
          </div>
        </div>

        <div className="relative mb-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input
              ref={searchInputRef}
              placeholder="Search your notes..."
              className="pl-10 bg-white dark:bg-gray-800 border-purple-100 dark:border-gray-700 focus-visible:ring-purple-500 rounded-full h-12"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            {searchQuery && (
              <button
                className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200"
                onClick={() => setSearchQuery("")}
              >
                <X className="h-4 w-4" />
              </button>
            )}
          </div>

          {/* AI Tag Suggestions */}
          <AnimatePresence>
            {suggestedTags.length > 0 && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="absolute top-full left-0 right-0 mt-2 p-3 bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-purple-100 dark:border-gray-700 z-10"
              >
                <div className="flex items-center gap-2 mb-2">
                  <Sparkles className="h-4 w-4 text-pink-500" />
                  <span className="text-xs font-medium text-transparent bg-clip-text bg-gradient-to-r from-purple-500 to-pink-500">
                    AI Suggested Tags:
                  </span>
                </div>
                <div className="flex flex-wrap gap-2">
                  {suggestedTags.map((tag, index) => (
                    <motion.button
                      key={tag}
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: index * 0.1 }}
                      whileHover={{ scale: 1.1 }}
                      className="px-3 py-1.5 text-xs rounded-full bg-gradient-to-r from-purple-100 to-pink-100 dark:from-purple-900/30 dark:to-pink-900/30 text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-pink-600 dark:from-purple-400 dark:to-pink-400 border border-purple-200 dark:border-purple-800/30"
                      onClick={() => handleTagClick(tag)}
                    >
                      {tag}
                    </motion.button>
                  ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Category Filters */}
        <div className="flex flex-wrap gap-2 mb-6">
          {CATEGORIES.map((category) => (
            <motion.button
              key={category.name}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className={`px-3 py-1.5 text-xs rounded-full border border-transparent hover:border-purple-200 dark:hover:border-purple-800 transition-colors flex items-center gap-1.5 bg-gradient-to-r from-${category.gradient}/10 hover:from-${category.gradient}/20 hover:to-${category.gradient}/20`}
            >
              <span className={`w-2 h-2 rounded-full ${category.color}`}></span>
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-${category.gradient}">
                {category.name}
              </span>
            </motion.button>
          ))}
        </div>

        {/* Notes Content */}
        <div className="flex-1">
          {isSearching ? (
            <div className="flex items-center justify-center h-64">
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
              >
                <Zap className="h-10 w-10 text-purple-500" />
              </motion.div>
            </div>
          ) : activeView === "list" ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {searchResults.length > 0 ? (
                searchResults.map((note) => <NoteCard key={note.id} note={note} />)
              ) : (
                <div className="col-span-2 flex flex-col items-center justify-center h-64 text-center">
                  <FileText className="h-16 w-16 text-gray-300 dark:text-gray-600 mb-4" />
                  <h3 className="text-xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-500 to-pink-500 mb-2">
                    No notes found
                  </h3>
                  <p className="text-gray-500 dark:text-gray-400">Try adjusting your search or filters</p>
                </div>
              )}
            </div>
          ) : (
            <Card className="border-2 border-purple-100 dark:border-gray-700 rounded-xl overflow-hidden">
              <CardContent className="p-4">
                <NoteGraph notes={searchResults} />
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}
