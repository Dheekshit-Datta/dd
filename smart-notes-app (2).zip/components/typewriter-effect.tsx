"use client"

import { useEffect, useState } from "react"
import { motion, stagger, useAnimate, useInView } from "framer-motion"

export const TypewriterEffect = ({
  words,
  className,
  cursorClassName,
}: {
  words: {
    text: string
    className?: string
  }[]
  className?: string
  cursorClassName?: string
}) => {
  const [scope, animate] = useAnimate()
  const isInView = useInView(scope)
  const [started, setStarted] = useState(false)

  useEffect(() => {
    if (isInView && !started) {
      setStarted(true)

      const wordsArray = words.map((word) => word.text)
      const textToType = wordsArray.join(" ")

      const letterAnimation = async () => {
        await animate(
          "span",
          {
            opacity: 1,
          },
          {
            duration: 0.1,
            delay: stagger(0.05),
          },
        )
      }

      letterAnimation()
    }
  }, [isInView, animate, words, started])

  const renderWords = () => {
    return (
      <div className="inline">
        {words.map((word, idx) => {
          return (
            <div key={`word-${idx}`} className="inline-block">
              {word.text.split("").map((char, index) => (
                <motion.span initial={{ opacity: 0 }} key={`char-${index}`} className={word.className}>
                  {char}
                </motion.span>
              ))}
              &nbsp;
            </div>
          )
        })}
      </div>
    )
  }

  return (
    <div ref={scope} className={className}>
      {renderWords()}
      <motion.span
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{
          duration: 0.8,
          repeat: Number.POSITIVE_INFINITY,
          repeatType: "reverse",
        }}
        className={cursorClassName}
      >
        |
      </motion.span>
    </div>
  )
}
