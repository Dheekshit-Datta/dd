import { Sidebar } from "@/components/sidebar"
import { AnalyticsView } from "@/components/analytics-view"

export default function AnalyticsPage() {
  return (
    <div className="flex h-screen bg-background overflow-hidden">
      <Sidebar />
      <main className="flex-1 overflow-auto">
        <AnalyticsView />
      </main>
    </div>
  )
}
