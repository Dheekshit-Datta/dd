import { Sidebar } from "@/components/sidebar"
import { CalendarView } from "@/components/calendar-view"

export default function CalendarPage() {
  return (
    <div className="flex h-screen bg-background overflow-hidden">
      <Sidebar />
      <main className="flex-1 overflow-auto p-6">
        <CalendarView />
      </main>
    </div>
  )
}
