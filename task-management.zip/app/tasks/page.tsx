import { Sidebar } from "@/components/sidebar"
import { TasksWithCategories } from "@/components/tasks-with-categories"

export default function TasksPage() {
  return (
    <div className="flex h-screen bg-background overflow-hidden">
      <Sidebar />
      <main className="flex-1 overflow-auto p-6">
        <TasksWithCategories />
      </main>
    </div>
  )
}
