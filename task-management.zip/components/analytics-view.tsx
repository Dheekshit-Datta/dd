"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Area,
  BarChart,
  Bar,
  Legend,
} from "recharts"
import { CheckCircle, Clock, AlertCircle, Flag, Award, Target, ArrowUpRight, ArrowDownRight, Zap } from "lucide-react"
import { cn } from "@/lib/utils"
import { format, subDays, eachDayOfInterval, isSameDay } from "date-fns"

export function AnalyticsView() {
  const [selectedPeriod, setSelectedPeriod] = useState("week")
  const [animatedStats, setAnimatedStats] = useState({
    completed: 0,
    inProgress: 0,
    toStart: 0,
    overdue: 0,
    productivity: 0,
    streak: 0,
  })

  // Sample data for analytics
  const taskCompletionData = [
    { date: subDays(new Date(), 6), completed: 3, total: 5 },
    { date: subDays(new Date(), 5), completed: 4, total: 6 },
    { date: subDays(new Date(), 4), completed: 2, total: 4 },
    { date: subDays(new Date(), 3), completed: 5, total: 7 },
    { date: subDays(new Date(), 2), completed: 3, total: 5 },
    { date: subDays(new Date(), 1), completed: 2, total: 3 },
    { date: new Date(), completed: 1, total: 2 },
  ]

  const formattedTaskCompletionData = taskCompletionData.map((item) => ({
    name: format(item.date, "EEE"),
    completed: item.completed,
    total: item.total,
    date: item.date,
  }))

  const productivityTrendData = [
    { name: "Week 1", value: 65 },
    { name: "Week 2", value: 59 },
    { name: "Week 3", value: 80 },
    { name: "Week 4", value: 81 },
    { name: "Week 5", value: 76 },
    { name: "Week 6", value: 85 },
    { name: "Week 7", value: 90 },
  ]

  const tasksByPriority = [
    { name: "High", value: 8, color: "var(--high-priority)" },
    { name: "Medium", value: 12, color: "var(--medium-priority)" },
    { name: "Low", value: 6, color: "var(--low-priority)" },
  ]

  const tasksByCategory = [
    { name: "Personal", value: 7, color: "hsl(var(--chart-1))" },
    { name: "Health", value: 5, color: "hsl(var(--chart-2))" },
    { name: "Finance", value: 4, color: "hsl(var(--chart-3))" },
    { name: "Learning", value: 6, color: "hsl(var(--chart-4))" },
    { name: "Home", value: 3, color: "hsl(var(--chart-5))" },
    { name: "Shopping", value: 2, color: "hsl(var(--chart-1))" },
  ]

  const taskStatusSummary = [
    {
      status: "Completed",
      count: 18,
      icon: CheckCircle,
      color: "text-green-500",
      bgColor: "bg-green-50",
      progressColor: "bg-green-500",
      change: 12,
      changeType: "increase",
    },
    {
      status: "In Progress",
      count: 7,
      icon: Clock,
      color: "text-amber-500",
      bgColor: "bg-amber-50",
      progressColor: "bg-amber-500",
      change: 3,
      changeType: "increase",
    },
    {
      status: "To Start",
      count: 12,
      icon: AlertCircle,
      color: "text-blue-500",
      bgColor: "bg-blue-50",
      progressColor: "bg-blue-500",
      change: 2,
      changeType: "decrease",
    },
    {
      status: "Overdue",
      count: 3,
      icon: Flag,
      color: "text-red-500",
      bgColor: "bg-red-50",
      progressColor: "bg-red-500",
      change: 1,
      changeType: "decrease",
    },
  ]

  // Generate heatmap data
  const today = new Date()
  const last90Days = eachDayOfInterval({
    start: subDays(today, 89),
    end: today,
  })

  const heatmapData = last90Days.map((date) => {
    // Generate random activity level (0-4)
    const activityLevel = Math.floor(Math.random() * 5)

    // Find if there's a matching date in taskCompletionData
    const matchingData = taskCompletionData.find((item) => isSameDay(item.date, date))

    return {
      date,
      value: matchingData ? matchingData.completed : activityLevel,
      tooltip: `${format(date, "MMM d, yyyy")}: ${matchingData ? matchingData.completed : activityLevel} tasks`,
    }
  })

  const totalTasks = taskStatusSummary.reduce((acc, item) => acc + item.count, 0)
  const completedTasks = taskStatusSummary.find((item) => item.status === "Completed")?.count || 0
  const completionPercentage = Math.round((completedTasks / totalTasks) * 100)

  // Animate stats on mount
  useEffect(() => {
    const completedCount = taskStatusSummary.find((item) => item.status === "Completed")?.count || 0
    const inProgressCount = taskStatusSummary.find((item) => item.status === "In Progress")?.count || 0
    const toStartCount = taskStatusSummary.find((item) => item.status === "To Start")?.count || 0
    const overdueCount = taskStatusSummary.find((item) => item.status === "Overdue")?.count || 0

    const timer = setTimeout(() => {
      setAnimatedStats({
        completed: completedCount,
        inProgress: inProgressCount,
        toStart: toStartCount,
        overdue: overdueCount,
        productivity: 85,
        streak: 12,
      })
    }, 300)

    return () => clearTimeout(timer)
  }, [])

  // CSS variables for priority colors
  useEffect(() => {
    document.documentElement.style.setProperty("--high-priority", "#ef4444")
    document.documentElement.style.setProperty("--medium-priority", "#f59e0b")
    document.documentElement.style.setProperty("--low-priority", "#10b981")

    return () => {
      document.documentElement.style.removeProperty("--high-priority")
      document.documentElement.style.removeProperty("--medium-priority")
      document.documentElement.style.removeProperty("--low-priority")
    }
  }, [])

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Analytics Dashboard</h1>
        <Select defaultValue={selectedPeriod} onValueChange={setSelectedPeriod}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Select time period" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="day">Today</SelectItem>
            <SelectItem value="week">This Week</SelectItem>
            <SelectItem value="month">This Month</SelectItem>
            <SelectItem value="quarter">This Quarter</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Top Stats Row */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {taskStatusSummary.map((item) => (
          <Card key={item.status} className="stat-card">
            <div className={cn("stat-card-header", item.progressColor)} />
            <div className="flex justify-between items-start">
              <div>
                <p className="stat-label">{item.status}</p>
                <h3 className="stat-value animated-counter">
                  {animatedStats[item.status.toLowerCase().replace(" ", "")] || 0}
                </h3>
                <div className="flex items-center mt-1 text-xs">
                  {item.changeType === "increase" ? (
                    <ArrowUpRight className="h-3 w-3 text-green-500 mr-1" />
                  ) : (
                    <ArrowDownRight className="h-3 w-3 text-red-500 mr-1" />
                  )}
                  <span className={item.changeType === "increase" ? "text-green-500" : "text-red-500"}>
                    {item.change}% from last {selectedPeriod}
                  </span>
                </div>
              </div>
              <div className={cn("stat-icon", item.bgColor)}>
                <item.icon className={cn("h-5 w-5", item.color)} />
              </div>
            </div>
            <div className="stat-progress">
              <div
                className={cn("stat-progress-bar", item.progressColor)}
                style={{ width: `${Math.round((item.count / totalTasks) * 100)}%` }}
              />
            </div>
          </Card>
        ))}
      </div>

      {/* Productivity Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="stat-card md:col-span-1">
          <div className="stat-card-header bg-primary" />
          <div className="flex justify-between items-start">
            <div>
              <p className="stat-label">Productivity Score</p>
              <div className="flex items-baseline">
                <h3 className="stat-value animated-counter">{animatedStats.productivity}</h3>
                <span className="text-sm text-muted-foreground ml-1">/100</span>
              </div>
              <div className="flex items-center mt-1 text-xs">
                <ArrowUpRight className="h-3 w-3 text-green-500 mr-1" />
                <span className="text-green-500">5% from last week</span>
              </div>
            </div>
            <div className="stat-icon bg-primary/10">
              <Target className="h-5 w-5 text-primary" />
            </div>
          </div>
          <div className="stat-progress">
            <div className="stat-progress-bar bg-primary" style={{ width: `${animatedStats.productivity}%` }} />
          </div>
        </Card>

        <Card className="stat-card md:col-span-1">
          <div className="stat-card-header bg-amber-500" />
          <div className="flex justify-between items-start">
            <div>
              <p className="stat-label">Current Streak</p>
              <div className="flex items-baseline">
                <h3 className="stat-value animated-counter">{animatedStats.streak}</h3>
                <span className="text-sm text-muted-foreground ml-1">days</span>
              </div>
              <div className="flex items-center mt-1 text-xs">
                <span className="text-muted-foreground">Best: 15 days</span>
              </div>
            </div>
            <div className="stat-icon bg-amber-50">
              <Zap className="h-5 w-5 text-amber-500" />
            </div>
          </div>
          <div className="stat-progress">
            <div
              className="stat-progress-bar bg-amber-500"
              style={{ width: `${(animatedStats.streak / 15) * 100}%` }}
            />
          </div>
        </Card>

        <Card className="stat-card md:col-span-1">
          <div className="stat-card-header bg-blue-500" />
          <div className="flex justify-between items-start">
            <div>
              <p className="stat-label">Completion Rate</p>
              <div className="flex items-baseline">
                <h3 className="stat-value animated-counter">{completionPercentage}</h3>
                <span className="text-sm text-muted-foreground ml-1">%</span>
              </div>
              <div className="flex items-center mt-1 text-xs">
                <ArrowUpRight className="h-3 w-3 text-green-500 mr-1" />
                <span className="text-green-500">8% from last month</span>
              </div>
            </div>
            <div className="stat-icon bg-blue-50">
              <Award className="h-5 w-5 text-blue-500" />
            </div>
          </div>
          <div className="stat-progress">
            <div className="stat-progress-bar bg-blue-500" style={{ width: `${completionPercentage}%` }} />
          </div>
        </Card>
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="col-span-1 overflow-hidden">
          <CardHeader className="pb-2">
            <CardTitle>Task Completion</CardTitle>
            <CardDescription>Daily task completion rate</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[300px] animated-chart">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={formattedTaskCompletionData} margin={{ top: 20, right: 30, left: 0, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                  <XAxis dataKey="name" stroke="var(--muted-foreground)" />
                  <YAxis stroke="var(--muted-foreground)" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "var(--card)",
                      borderColor: "var(--border)",
                      color: "var(--card-foreground)",
                    }}
                  />
                  <Legend />
                  <Bar name="Completed" dataKey="completed" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                  <Bar name="Total" dataKey="total" fill="hsl(var(--muted))" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card className="col-span-1 overflow-hidden">
          <CardHeader className="pb-2">
            <CardTitle>Productivity Trend</CardTitle>
            <CardDescription>Weekly productivity score</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[300px] animated-chart">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={productivityTrendData} margin={{ top: 20, right: 30, left: 0, bottom: 5 }}>
                  <defs>
                    <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.8} />
                      <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0.2} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                  <XAxis dataKey="name" stroke="var(--muted-foreground)" />
                  <YAxis stroke="var(--muted-foreground)" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "var(--card)",
                      borderColor: "var(--border)",
                      color: "var(--card-foreground)",
                    }}
                  />
                  <Area
                    type="monotone"
                    dataKey="value"
                    stroke="hsl(var(--primary))"
                    fillOpacity={1}
                    fill="url(#colorValue)"
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Distribution and Heatmap */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="col-span-1 overflow-hidden">
          <CardHeader className="pb-2">
            <CardTitle>Task Distribution</CardTitle>
            <CardDescription>Breakdown by priority and category</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="priority">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="priority">By Priority</TabsTrigger>
                <TabsTrigger value="category">By Category</TabsTrigger>
              </TabsList>
              <TabsContent value="priority" className="h-[250px] mt-4 animated-chart">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={tasksByPriority}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={80}
                      paddingAngle={5}
                      dataKey="value"
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    >
                      {tasksByPriority.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "var(--card)",
                        borderColor: "var(--border)",
                        color: "var(--card-foreground)",
                      }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </TabsContent>
              <TabsContent value="category" className="h-[250px] mt-4 animated-chart">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={tasksByCategory}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={80}
                      paddingAngle={5}
                      dataKey="value"
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    >
                      {tasksByCategory.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "var(--card)",
                        borderColor: "var(--border)",
                        color: "var(--card-foreground)",
                      }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        <Card className="col-span-1 md:col-span-2 overflow-hidden">
          <CardHeader className="pb-2">
            <CardTitle>Activity Heatmap</CardTitle>
            <CardDescription>Your task completion history</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[250px] overflow-auto">
              <div className="relative">
                <div className="flex flex-col gap-1">
                  {Array.from({ length: 13 }).map((_, weekIndex) => (
                    <div key={weekIndex} className="flex gap-1">
                      {Array.from({ length: 7 }).map((_, dayIndex) => {
                        const dataIndex = weekIndex * 7 + dayIndex
                        if (dataIndex >= heatmapData.length) return null

                        const data = heatmapData[dataIndex]
                        const intensity = data.value

                        let bgColor
                        if (intensity === 0) bgColor = "bg-gray-100"
                        else if (intensity === 1) bgColor = "bg-primary/20"
                        else if (intensity === 2) bgColor = "bg-primary/40"
                        else if (intensity === 3) bgColor = "bg-primary/60"
                        else bgColor = "bg-primary/80"

                        return (
                          <div key={dayIndex} className={cn("heatmap-cell w-4 h-4", bgColor)} title={data.tooltip} />
                        )
                      })}
                    </div>
                  ))}
                </div>

                <div className="mt-2 flex justify-between text-xs text-muted-foreground">
                  <span>{format(subDays(today, 89), "MMM d")}</span>
                  <span>{format(today, "MMM d")}</span>
                </div>

                <div className="mt-4 flex items-center gap-2">
                  <span className="text-xs text-muted-foreground">Less</span>
                  <div className="flex gap-1">
                    <div className="heatmap-cell w-3 h-3 bg-gray-100" />
                    <div className="heatmap-cell w-3 h-3 bg-primary/20" />
                    <div className="heatmap-cell w-3 h-3 bg-primary/40" />
                    <div className="heatmap-cell w-3 h-3 bg-primary/60" />
                    <div className="heatmap-cell w-3 h-3 bg-primary/80" />
                  </div>
                  <span className="text-xs text-muted-foreground">More</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
