"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ChevronLeft, ChevronRight, Flag } from "lucide-react"
import {
  format,
  isSameDay,
  addMonths,
  subMonths,
  startOfMonth,
  endOfMonth,
  eachDayOfInterval,
  isSameMonth,
} from "date-fns"
import { cn } from "@/lib/utils"
import type { Task, Priority, Category } from "@/types/task"

export function CalendarView() {
  const [currentMonth, setCurrentMonth] = useState<Date>(new Date())
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date())
  const [filter, setFilter] = useState<{
    priority: Priority | "all"
    category: Category | "all"
  }>({
    priority: "all",
    category: "all",
  })

  // Sample tasks data
  const tasks: Task[] = [
    {
      id: "task-1",
      title: "Building Design systems Case Study documentation",
      description: "Create comprehensive documentation for the design system case study",
      priority: "high",
      category: "design",
      dueDate: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000),
      completed: false,
      assignees: [
        { id: "user-1", name: "Alex", image: "/placeholder.svg?height=32&width=32" },
        { id: "user-2", name: "Taylor", image: "/placeholder.svg?height=32&width=32" },
      ],
      comments: 5,
    },
    {
      id: "task-2",
      title: "Create the Design systems documents",
      description: "Prepare design system documentation",
      priority: "medium",
      category: "design",
      dueDate: new Date(Date.now() + 4 * 24 * 60 * 60 * 1000),
      completed: false,
      assignees: [{ id: "user-1", name: "Alex", image: "/placeholder.svg?height=32&width=32" }],
      comments: 3,
    },
    {
      id: "task-3",
      title: "Update Design Team roles",
      description: "Restructure the design team roles",
      priority: "high",
      category: "management",
      dueDate: new Date(Date.now() + 1 * 24 * 60 * 60 * 1000),
      completed: false,
      assignees: [{ id: "user-2", name: "Taylor", image: "/placeholder.svg?height=32&width=32" }],
      comments: 8,
    },
    {
      id: "task-4",
      title: "Prepare Task Tracker for UI/UX designers",
      description: "Set up task tracking system",
      priority: "medium",
      category: "onboarding",
      dueDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000),
      completed: false,
      assignees: [{ id: "user-1", name: "Alex", image: "/placeholder.svg?height=32&width=32" }],
      comments: 2,
    },
    {
      id: "task-5",
      title: "Design system usage analytics",
      description: "Gather and analyze data on design system usage",
      priority: "medium",
      category: "analytics",
      dueDate: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
      completed: true,
      assignees: [{ id: "user-4", name: "Casey", image: "/placeholder.svg?height=32&width=32" }],
      comments: 4,
    },
  ]

  const filteredTasks = tasks.filter((task) => {
    const priorityMatch = filter.priority === "all" || task.priority === filter.priority
    const categoryMatch = filter.category === "all" || task.category === filter.category
    return priorityMatch && categoryMatch
  })

  const selectedDateTasks = selectedDate ? filteredTasks.filter((task) => isSameDay(task.dueDate, selectedDate)) : []

  const handlePreviousMonth = () => {
    setCurrentMonth(subMonths(currentMonth, 1))
  }

  const handleNextMonth = () => {
    setCurrentMonth(addMonths(currentMonth, 1))
  }

  const daysInMonth = eachDayOfInterval({
    start: startOfMonth(currentMonth),
    end: endOfMonth(currentMonth),
  })

  const getPriorityColor = (priority: Priority) => {
    switch (priority) {
      case "high":
        return "text-red-500"
      case "medium":
        return "text-amber-500"
      case "low":
        return "text-green-500"
      default:
        return ""
    }
  }

  const categories: { value: Category; label: string }[] = [
    { value: "design", label: "Design" },
    { value: "development", label: "Development" },
    { value: "marketing", label: "Marketing" },
    { value: "management", label: "Management" },
    { value: "analytics", label: "Analytics" },
    { value: "presentation", label: "Presentation" },
    { value: "onboarding", label: "Onboarding" },
  ]

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Calendar</h1>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={handlePreviousMonth}>
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <h2 className="text-lg font-medium px-2">{format(currentMonth, "MMMM yyyy")}</h2>
          <Button variant="outline" size="sm" onClick={handleNextMonth}>
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2">
          <Card>
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle>Task Calendar</CardTitle>
                <div className="flex items-center gap-2">
                  <Select
                    value={filter.priority}
                    onValueChange={(value) => setFilter({ ...filter, priority: value as Priority | "all" })}
                  >
                    <SelectTrigger className="w-[140px] h-8">
                      <SelectValue placeholder="Priority" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Priorities</SelectItem>
                      <SelectItem value="high">High Priority</SelectItem>
                      <SelectItem value="medium">Medium Priority</SelectItem>
                      <SelectItem value="low">Low Priority</SelectItem>
                    </SelectContent>
                  </Select>

                  <Select
                    value={filter.category}
                    onValueChange={(value) => setFilter({ ...filter, category: value as Category | "all" })}
                  >
                    <SelectTrigger className="w-[140px] h-8">
                      <SelectValue placeholder="Category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Categories</SelectItem>
                      {categories.map((category) => (
                        <SelectItem key={category.value} value={category.value}>
                          {category.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-7 gap-px bg-muted rounded-lg overflow-hidden">
                {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((day) => (
                  <div key={day} className="bg-card p-2 text-center text-sm font-medium">
                    {day}
                  </div>
                ))}

                {Array.from({ length: startOfMonth(currentMonth).getDay() }).map((_, i) => (
                  <div key={`empty-start-${i}`} className="bg-card p-2" />
                ))}

                {daysInMonth.map((day) => {
                  const dayTasks = filteredTasks.filter((task) => isSameDay(task.dueDate, day))
                  const isSelected = selectedDate && isSameDay(day, selectedDate)
                  const isCurrentMonth = isSameMonth(day, currentMonth)

                  return (
                    <div
                      key={day.toString()}
                      className={cn(
                        "bg-card p-2 min-h-[80px] relative",
                        !isCurrentMonth && "opacity-50",
                        isSelected && "ring-2 ring-black",
                      )}
                      onClick={() => setSelectedDate(day)}
                    >
                      <div className="text-right text-sm">{format(day, "d")}</div>
                      <div className="mt-1 space-y-1">
                        {dayTasks.slice(0, 2).map((task) => (
                          <div
                            key={task.id}
                            className={cn(
                              "text-xs p-1 rounded truncate",
                              task.priority === "high"
                                ? "bg-red-100"
                                : task.priority === "medium"
                                  ? "bg-amber-100"
                                  : "bg-green-100",
                            )}
                          >
                            {task.title.length > 20 ? `${task.title.substring(0, 20)}...` : task.title}
                          </div>
                        ))}
                        {dayTasks.length > 2 && (
                          <div className="text-xs text-center text-muted-foreground">+{dayTasks.length - 2} more</div>
                        )}
                      </div>
                    </div>
                  )
                })}

                {Array.from({ length: 6 * 7 - (startOfMonth(currentMonth).getDay() + daysInMonth.length) }).map(
                  (_, i) => (
                    <div key={`empty-end-${i}`} className="bg-card p-2" />
                  ),
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        <div>
          <Card className="h-full">
            <CardHeader>
              <CardTitle>{selectedDate ? format(selectedDate, "MMMM d, yyyy") : "Select a date"}</CardTitle>
            </CardHeader>
            <CardContent>
              {selectedDateTasks.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">No tasks scheduled for this day</div>
              ) : (
                <div className="space-y-4">
                  {selectedDateTasks.map((task) => (
                    <div key={task.id} className="border rounded-lg p-3">
                      <div className="flex items-start justify-between mb-2">
                        <Badge
                          variant="outline"
                          className={cn(
                            "text-xs",
                            task.category === "design"
                              ? "bg-purple-100 text-purple-800"
                              : task.category === "development"
                                ? "bg-blue-100 text-blue-800"
                                : task.category === "management"
                                  ? "bg-amber-100 text-amber-800"
                                  : "bg-gray-100 text-gray-800",
                          )}
                        >
                          {task.category.charAt(0).toUpperCase() + task.category.slice(1)}
                        </Badge>
                        <Flag className={cn("h-4 w-4", getPriorityColor(task.priority))} fill="currentColor" />
                      </div>

                      <h4 className="font-medium text-sm mb-1">{task.title}</h4>
                      <p className="text-xs text-muted-foreground mb-3">{task.description}</p>

                      <div className="flex justify-between items-center">
                        <div className="flex -space-x-2">
                          {task.assignees.map((assignee) => (
                            <Avatar key={assignee.id} className="h-6 w-6 border-2 border-white">
                              <AvatarImage src={assignee.image || "/placeholder.svg"} alt={assignee.name} />
                              <AvatarFallback>{assignee.name.charAt(0)}</AvatarFallback>
                            </Avatar>
                          ))}
                        </div>

                        <Badge variant={task.completed ? "outline" : "secondary"} className="text-xs">
                          {task.completed ? "Completed" : "In Progress"}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
