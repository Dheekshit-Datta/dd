"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Button } from "@/components/ui/button"
import { LayoutDashboard, CalendarDays, BarChart3, CheckSquare, PlusCircle, Settings, Palette } from "lucide-react"
import { cn } from "@/lib/utils"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { ThemeSwitcher } from "./theme-switcher"

export function Sidebar() {
  const pathname = usePathname()
  const [collapsed, setCollapsed] = useState(false)
  const [isThemeDialogOpen, setIsThemeDialogOpen] = useState(false)

  const mainNavItems = [
    {
      title: "Daily Task List",
      href: "/",
      icon: LayoutDashboard,
    },
    {
      title: "Tasks",
      href: "/tasks",
      icon: CheckSquare,
    },
    {
      title: "Calendar",
      href: "/calendar",
      icon: CalendarDays,
    },
    {
      title: "Analytics",
      href: "/analytics",
      icon: BarChart3,
    },
  ]

  return (
    <div
      className={cn(
        "h-full border-r bg-card flex flex-col transition-all duration-300",
        collapsed ? "w-[70px]" : "w-[240px]",
      )}
    >
      <div className="p-4 flex items-center justify-between border-b">
        <div className={cn("flex items-center", collapsed && "justify-center w-full")}>
          <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center">
            <span className="text-primary-foreground text-xs font-bold">T</span>
          </div>
          {!collapsed && <span className="ml-2 font-semibold">Taskify</span>}
        </div>
        {!collapsed && (
          <Button variant="ghost" size="icon" onClick={() => setCollapsed(true)} className="h-8 w-8 rounded-full">
            <Settings className="h-4 w-4" />
          </Button>
        )}
        {collapsed && (
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setCollapsed(false)}
            className="h-8 w-8 absolute -right-4 top-4 bg-card border rounded-full"
          >
            <Settings className="h-4 w-4" />
          </Button>
        )}
      </div>

      <div className="flex-1 overflow-auto py-2">
        <div className="px-3 py-2">
          {!collapsed && <h3 className="text-xs font-medium text-muted-foreground mb-2 px-2">MAIN MENU</h3>}
          <nav className="space-y-1">
            {mainNavItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "flex items-center px-3 py-2 text-sm rounded-full",
                  pathname === item.href
                    ? "bg-secondary text-foreground font-medium"
                    : "text-muted-foreground hover:bg-secondary/50",
                )}
              >
                <item.icon className={cn("h-4 w-4", collapsed ? "mx-auto" : "mr-2")} />
                {!collapsed && <span>{item.title}</span>}
              </Link>
            ))}
          </nav>
        </div>
      </div>

      <div className="p-3 border-t space-y-3">
        <Dialog open={isThemeDialogOpen} onOpenChange={setIsThemeDialogOpen}>
          <DialogTrigger asChild>
            <Button variant="outline" className={cn("w-full justify-center", collapsed ? "px-2" : "")}>
              <Palette className={cn("h-4 w-4", collapsed ? "" : "mr-2")} />
              {!collapsed && <span>Themes</span>}
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Appearance</DialogTitle>
            </DialogHeader>
            <ThemeSwitcher />
          </DialogContent>
        </Dialog>

        <Button className={cn("btn-create w-full justify-center", collapsed ? "px-2" : "")}>
          <PlusCircle className={cn("h-4 w-4", collapsed ? "" : "mr-2")} />
          {!collapsed && <span>Create Task</span>}
        </Button>
      </div>
    </div>
  )
}
