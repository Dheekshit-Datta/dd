"use client"

import { useState } from "react"
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { TaskForm } from "@/components/task-form"
import { MoreHorizontal, Plus, Search } from "lucide-react"
import { cn } from "@/lib/utils"
import { TaskCard } from "@/components/task-card"
import { Input } from "@/components/ui/input"
import type { Task, Column } from "@/types/task"

export function TaskBoard() {
  const [columns, setColumns] = useState<Column[]>([
    {
      id: "to-start",
      title: "To Start",
      color: "bg-[hsl(var(--todo-color))]",
      tasks: [
        {
          id: "task-1",
          title: "Plan weekly grocery shopping",
          description: "Make a list of items needed for the week's meals",
          priority: "medium",
          category: "personal",
          dueDate: new Date(Date.now() + 1 * 24 * 60 * 60 * 1000),
          completed: false,
          assignees: [],
          comments: 0,
        },
        {
          id: "task-2",
          title: "Schedule dentist appointment",
          description: "Call Dr. Smith's office for a checkup",
          priority: "low",
          category: "health",
          dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
          completed: false,
          assignees: [],
          comments: 0,
        },
      ],
    },
    {
      id: "in-progress",
      title: "In Progress",
      color: "bg-[hsl(var(--progress-color))]",
      tasks: [
        {
          id: "task-3",
          title: "Learn React hooks",
          description: "Complete the tutorial on useState and useEffect",
          priority: "high",
          category: "learning",
          dueDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000),
          completed: false,
          assignees: [],
          comments: 0,
        },
        {
          id: "task-4",
          title: "Organize home office",
          description: "Clean desk and organize cables",
          priority: "medium",
          category: "home",
          dueDate: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000),
          completed: false,
          assignees: [],
          comments: 0,
        },
      ],
    },
    {
      id: "done",
      title: "Done",
      color: "bg-[hsl(var(--done-color))]",
      tasks: [
        {
          id: "task-5",
          title: "Pay monthly bills",
          description: "Electricity, internet, and water bills",
          priority: "high",
          category: "finance",
          dueDate: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
          completed: true,
          assignees: [],
          comments: 0,
        },
        {
          id: "task-6",
          title: "Buy birthday gift for mom",
          description: "Look for that book she mentioned",
          priority: "medium",
          category: "personal",
          dueDate: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
          completed: true,
          assignees: [],
          comments: 0,
        },
      ],
    },
  ])

  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")

  const handleDragEnd = (result: any) => {
    const { destination, source, draggableId } = result

    // If there's no destination or the item is dropped in the same place
    if (!destination || (destination.droppableId === source.droppableId && destination.index === source.index)) {
      return
    }

    // Find the source and destination columns
    const sourceColumn = columns.find((col) => col.id === source.droppableId)
    const destColumn = columns.find((col) => col.id === destination.droppableId)

    if (!sourceColumn || !destColumn) return

    // Create new arrays for the columns
    const newColumns = [...columns]

    // Find the task that was dragged
    const task = sourceColumn.tasks.find((task) => task.id === draggableId)
    if (!task) return

    // Remove the task from the source column
    const newSourceTasks = [...sourceColumn.tasks]
    newSourceTasks.splice(source.index, 1)

    // Add the task to the destination column
    const newDestTasks = [...destColumn.tasks]
    newDestTasks.splice(destination.index, 0, task)

    // Update the columns state
    const sourceColIndex = columns.findIndex((col) => col.id === source.droppableId)
    const destColIndex = columns.findIndex((col) => col.id === destination.droppableId)

    newColumns[sourceColIndex] = {
      ...sourceColumn,
      tasks: newSourceTasks,
    }

    newColumns[destColIndex] = {
      ...destColumn,
      tasks: newDestTasks,
    }

    // If moving to "Done" column, mark as completed
    if (destination.droppableId === "done" && source.droppableId !== "done") {
      newColumns[destColIndex].tasks[destination.index].completed = true
    }

    // If moving from "Done" column, mark as not completed
    if (source.droppableId === "done" && destination.droppableId !== "done") {
      newColumns[destColIndex].tasks[destination.index].completed = false
    }

    setColumns(newColumns)
  }

  const handleAddTask = (task: Omit<Task, "id" | "assignees" | "comments" | "completed">) => {
    const newTask: Task = {
      ...task,
      id: `task-${Date.now()}`,
      assignees: [],
      comments: 0,
      completed: false,
    }

    const newColumns = [...columns]
    const toStartColumnIndex = newColumns.findIndex((col) => col.id === "to-start")

    newColumns[toStartColumnIndex] = {
      ...newColumns[toStartColumnIndex],
      tasks: [...newColumns[toStartColumnIndex].tasks, newTask],
    }

    setColumns(newColumns)
    setIsDialogOpen(false)
  }

  // Filter tasks based on search query
  const filteredColumns = columns.map((column) => ({
    ...column,
    tasks: column.tasks.filter(
      (task) =>
        task.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        task.description.toLowerCase().includes(searchQuery.toLowerCase()),
    ),
  }))

  return (
    <div className="p-6 dot-pattern">
      <div className="flex flex-col md:flex-row justify-between items-center mb-8 gap-4">
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="btn-create flex items-center gap-2">
              <Plus className="h-4 w-4" />
              Create Task
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[500px] rounded-2xl">
            <DialogHeader>
              <DialogTitle>Create New Task</DialogTitle>
            </DialogHeader>
            <TaskForm onAddTask={handleAddTask} />
          </DialogContent>
        </Dialog>

        <div className="flex items-center w-full md:w-auto">
          <div className="relative w-full md:w-64">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search tasks..."
              className="pl-10 rounded-full border-gray-200 focus:border-gray-300 focus:ring-gray-300"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>
      </div>

      <DragDropContext onDragEnd={handleDragEnd}>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {filteredColumns.map((column) => (
            <div key={column.id} className="flex flex-col">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <div className={cn("h-2 w-2 rounded-full", column.color)}></div>
                  <h3 className="font-semibold">{column.title}</h3>
                  <span className="text-xs text-muted-foreground bg-gray-100 px-2 py-0.5 rounded-full">
                    {column.tasks.length}
                  </span>
                </div>
                <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
                  <MoreHorizontal className="h-4 w-4" />
                </Button>
              </div>

              <Droppable droppableId={column.id}>
                {(provided, snapshot) => (
                  <div
                    {...provided.droppableProps}
                    ref={provided.innerRef}
                    className={cn(
                      "flex-1 min-h-[200px] rounded-2xl p-2",
                      snapshot.isDraggingOver ? "bg-[#f0f0f0]" : "bg-transparent",
                    )}
                  >
                    {column.tasks.map((task, index) => (
                      <Draggable key={task.id} draggableId={task.id} index={index}>
                        {(provided, snapshot) => (
                          <div
                            ref={provided.innerRef}
                            {...provided.draggableProps}
                            {...provided.dragHandleProps}
                            className={cn(
                              "mb-3 transform transition-transform",
                              snapshot.isDragging ? "rotate-1 scale-105" : "",
                            )}
                          >
                            <TaskCard task={task} columnColor={column.color} />
                          </div>
                        )}
                      </Draggable>
                    ))}
                    {provided.placeholder}
                  </div>
                )}
              </Droppable>
            </div>
          ))}
        </div>
      </DragDropContext>
    </div>
  )
}
