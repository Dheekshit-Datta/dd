"use client"

import { useState } from "react"
import type { Task } from "@/types/task"
import { Calendar } from "@/components/ui/calendar"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Flag } from "lucide-react"
import { format, isSameDay } from "date-fns"
import { cn } from "@/lib/utils"

interface TaskCalendarProps {
  tasks: Task[]
}

export function TaskCalendar({ tasks }: TaskCalendarProps) {
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date())

  // Group tasks by date
  const tasksByDate = tasks.reduce(
    (acc, task) => {
      const dateStr = format(task.dueDate, "yyyy-MM-dd")
      if (!acc[dateStr]) {
        acc[dateStr] = []
      }
      acc[dateStr].push(task)
      return acc
    },
    {} as Record<string, Task[]>,
  )

  // Get tasks for the selected date
  const selectedDateTasks = selectedDate ? tasks.filter((task) => isSameDay(task.dueDate, selectedDate)) : []

  const getPriorityColor = (priority: Task["priority"]) => {
    switch (priority) {
      case "high":
        return "text-red-500"
      case "medium":
        return "text-amber-500"
      case "low":
        return "text-green-500"
      default:
        return ""
    }
  }

  return (
    <div className="grid gap-6 md:grid-cols-2">
      <Card>
        <CardContent className="p-4">
          <Calendar
            mode="single"
            selected={selectedDate}
            onSelect={setSelectedDate}
            className="rounded-md border"
            components={{
              DayContent: (props) => {
                const dateStr = format(props.date, "yyyy-MM-dd")
                const dayTasks = tasksByDate[dateStr] || []

                return (
                  <div className="relative h-full w-full p-2">
                    <div className="text-center">{props.date.getDate()}</div>
                    {dayTasks.length > 0 && (
                      <div className="absolute bottom-1 left-0 right-0 flex justify-center">
                        <Badge variant="secondary" className="h-1.5 w-1.5 rounded-full p-0" />
                      </div>
                    )}
                  </div>
                )
              },
            }}
          />
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-4">
          <div className="space-y-4">
            <h3 className="font-medium">
              {selectedDate ? `Tasks for ${format(selectedDate, "MMMM d, yyyy")}` : "Select a date to view tasks"}
            </h3>
            {selectedDateTasks.length === 0 ? (
              <p className="text-muted-foreground text-sm">No tasks scheduled for this day.</p>
            ) : (
              <div className="space-y-3">
                {selectedDateTasks.map((task) => (
                  <div
                    key={task.id}
                    className={cn("flex items-start gap-2 rounded-lg border p-3", task.completed && "opacity-60")}
                  >
                    <Flag className={cn("h-4 w-4 mt-0.5", getPriorityColor(task.priority))} fill="currentColor" />
                    <div>
                      <p className={cn("font-medium", task.completed && "line-through text-muted-foreground")}>
                        {task.title}
                      </p>
                      {task.description && <p className="text-sm text-muted-foreground mt-1">{task.description}</p>}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
