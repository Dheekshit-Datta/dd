import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { Calendar } from "lucide-react"
import { cn } from "@/lib/utils"
import { format } from "date-fns"
import type { Task } from "@/types/task"

interface TaskCardProps {
  task: Task
  columnColor: string
}

export function TaskCard({ task, columnColor }: TaskCardProps) {
  const getPriorityColor = (priority: Task["priority"]) => {
    switch (priority) {
      case "high":
        return "bg-red-100 text-red-800 border-red-200"
      case "medium":
        return "bg-amber-100 text-amber-800 border-amber-200"
      case "low":
        return "bg-green-100 text-green-800 border-green-200"
      default:
        return "bg-gray-100 text-gray-800 border-gray-200"
    }
  }

  const getCategoryColor = (category: Task["category"]) => {
    switch (category) {
      case "personal":
        return "bg-purple-100 text-purple-800 border-purple-200"
      case "work":
        return "bg-blue-100 text-blue-800 border-blue-200"
      case "health":
        return "bg-green-100 text-green-800 border-green-200"
      case "finance":
        return "bg-amber-100 text-amber-800 border-amber-200"
      case "learning":
        return "bg-indigo-100 text-indigo-800 border-indigo-200"
      case "home":
        return "bg-pink-100 text-pink-800 border-pink-200"
      case "shopping":
        return "bg-cyan-100 text-cyan-800 border-cyan-200"
      default:
        return "bg-gray-100 text-gray-800 border-gray-200"
    }
  }

  return (
    <Card className="task-card overflow-hidden">
      <div className={cn("h-1", columnColor)} />
      <CardContent className="p-4">
        <div className="flex justify-between items-start mb-3">
          <Badge variant="outline" className={cn("text-xs font-medium rounded-full", getCategoryColor(task.category))}>
            {task.category.charAt(0).toUpperCase() + task.category.slice(1)}
          </Badge>
          <Badge variant="outline" className={cn("text-xs font-medium rounded-full", getPriorityColor(task.priority))}>
            {task.priority.charAt(0).toUpperCase() + task.priority.slice(1)}
          </Badge>
        </div>

        <h4 className="font-medium text-sm mb-2">{task.title}</h4>
        <p className="text-xs text-muted-foreground mb-4 line-clamp-2">{task.description}</p>

        <div className="flex justify-end items-center">
          <div className="flex items-center text-muted-foreground">
            <Calendar className="h-3 w-3 mr-1" />
            <span className="text-xs">{format(task.dueDate, "MMM d")}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
