"use client"

import { useState } from "react"
import { TaskList } from "./task-list"
import { TaskCalendar } from "./task-calendar"
import { TaskForm } from "./task-form"
import { ProgressBar } from "./progress-bar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import type { Task, Priority } from "@/types/task"
import { categorizeTask } from "@/lib/task-utils"

export function TaskDashboard() {
  const [tasks, setTasks] = useState<Task[]>([
    {
      id: "1",
      title: "Complete project proposal",
      description: "Finalize the project proposal for the client meeting",
      priority: "high",
      completed: false,
      dueDate: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000),
      category: "work",
    },
    {
      id: "2",
      title: "Buy groceries",
      description: "Milk, eggs, bread, and vegetables",
      priority: "medium",
      completed: true,
      dueDate: new Date(),
      category: "personal",
    },
    {
      id: "3",
      title: "Schedule dentist appointment",
      description: "Call Dr. Smith for a checkup",
      priority: "low",
      completed: false,
      dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
      category: "health",
    },
    {
      id: "4",
      title: "Review marketing strategy",
      description: "Analyze current marketing performance and suggest improvements",
      priority: "high",
      completed: false,
      dueDate: new Date(Date.now() + 1 * 24 * 60 * 60 * 1000),
      category: "work",
    },
  ])

  const completedTasksCount = tasks.filter((task) => task.completed).length
  const progressPercentage = tasks.length > 0 ? (completedTasksCount / tasks.length) * 100 : 0

  const addTask = (newTask: Omit<Task, "id" | "category">) => {
    const category = categorizeTask(newTask.title, newTask.description)
    const task: Task = {
      ...newTask,
      id: Date.now().toString(),
      category,
    }
    setTasks([...tasks, task])
  }

  const toggleTaskCompletion = (id: string) => {
    setTasks(tasks.map((task) => (task.id === id ? { ...task, completed: !task.completed } : task)))
  }

  const updateTaskPriority = (id: string, priority: Priority) => {
    setTasks(tasks.map((task) => (task.id === id ? { ...task, priority } : task)))
  }

  const deleteTask = (id: string) => {
    setTasks(tasks.filter((task) => task.id !== id))
  }

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      <div className="flex flex-col space-y-2">
        <h1 className="text-3xl font-bold tracking-tight">Task Manager</h1>
        <p className="text-muted-foreground">Organize your tasks with priorities and track your progress</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <div>
          <h2 className="text-xl font-semibold mb-4">Add New Task</h2>
          <TaskForm onAddTask={addTask} />
        </div>
        <div>
          <h2 className="text-xl font-semibold mb-4">Progress</h2>
          <div className="bg-card rounded-lg p-6 shadow-sm">
            <ProgressBar value={progressPercentage} />
            <p className="text-center mt-2 text-sm text-muted-foreground">
              {completedTasksCount} of {tasks.length} tasks completed
            </p>
          </div>
        </div>
      </div>

      <Tabs defaultValue="list" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="list">Task List</TabsTrigger>
          <TabsTrigger value="calendar">Calendar</TabsTrigger>
        </TabsList>
        <TabsContent value="list" className="mt-6">
          <TaskList
            tasks={tasks}
            onToggleCompletion={toggleTaskCompletion}
            onUpdatePriority={updateTaskPriority}
            onDeleteTask={deleteTask}
          />
        </TabsContent>
        <TabsContent value="calendar" className="mt-6">
          <TaskCalendar tasks={tasks} />
        </TabsContent>
      </Tabs>
    </div>
  )
}
