"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { CalendarIcon, Flag, Plus } from "lucide-react"
import { format } from "date-fns"
import { cn } from "@/lib/utils"
import type { Task, Priority, Category } from "@/types/task"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"

interface TaskFormProps {
  onAddTask: (task: Omit<Task, "id" | "assignees" | "comments" | "completed">) => void
}

export function TaskForm({ onAddTask }: TaskFormProps) {
  const [title, setTitle] = useState("")
  const [description, setDescription] = useState("")
  const [priority, setPriority] = useState<Priority>("medium")
  const [category, setCategory] = useState<Category>("personal")
  const [dueDate, setDueDate] = useState<Date>(new Date())
  const [newCategory, setNewCategory] = useState("")
  const [isAddCategoryOpen, setIsAddCategoryOpen] = useState(false)
  const [customCategories, setCustomCategories] = useState<Category[]>([])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!title.trim()) return

    onAddTask({
      title,
      description,
      priority,
      category,
      dueDate,
    })

    // Reset form
    setTitle("")
    setDescription("")
    setPriority("medium")
    setCategory("personal")
    setDueDate(new Date())
  }

  const handleAddCategory = () => {
    if (newCategory.trim()) {
      const formattedCategory = newCategory.toLowerCase().replace(/\s+/g, "-") as Category
      setCustomCategories([...customCategories, formattedCategory])
      setCategory(formattedCategory)
      setNewCategory("")
      setIsAddCategoryOpen(false)
    }
  }

  const defaultCategories: { value: Category; label: string }[] = [
    { value: "personal", label: "Personal" },
    { value: "work", label: "Work" },
    { value: "health", label: "Health" },
    { value: "finance", label: "Finance" },
    { value: "learning", label: "Learning" },
    { value: "home", label: "Home" },
    { value: "shopping", label: "Shopping" },
  ]

  // Combine default and custom categories
  const allCategories = [
    ...defaultCategories,
    ...customCategories.map((cat) => ({
      value: cat,
      label: cat.charAt(0).toUpperCase() + cat.slice(1).replace(/-/g, " "),
    })),
  ]

  return (
    <form onSubmit={handleSubmit} className="space-y-4 mt-4">
      <div className="space-y-2">
        <Input
          placeholder="Task title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          required
          className="border-gray-300 focus:border-black focus:ring-black rounded-full"
        />
      </div>

      <div className="space-y-2">
        <Textarea
          placeholder="Description (optional)"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          rows={3}
          className="border-gray-300 focus:border-black focus:ring-black rounded-xl"
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Select value={priority} onValueChange={(value) => setPriority(value as Priority)}>
            <SelectTrigger className="rounded-full">
              <SelectValue placeholder="Select priority" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="high">
                <div className="flex items-center">
                  <Flag className="mr-2 h-4 w-4 text-red-500" fill="currentColor" />
                  High Priority
                </div>
              </SelectItem>
              <SelectItem value="medium">
                <div className="flex items-center">
                  <Flag className="mr-2 h-4 w-4 text-amber-500" fill="currentColor" />
                  Medium Priority
                </div>
              </SelectItem>
              <SelectItem value="low">
                <div className="flex items-center">
                  <Flag className="mr-2 h-4 w-4 text-green-500" fill="currentColor" />
                  Low Priority
                </div>
              </SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <div className="flex gap-2">
            <Select value={category} onValueChange={(value) => setCategory(value as Category)} className="flex-1">
              <SelectTrigger className="rounded-full">
                <SelectValue placeholder="Select category" />
              </SelectTrigger>
              <SelectContent>
                {allCategories.map((category) => (
                  <SelectItem key={category.value} value={category.value}>
                    {category.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Dialog open={isAddCategoryOpen} onOpenChange={setIsAddCategoryOpen}>
              <DialogTrigger asChild>
                <Button variant="outline" size="icon" className="rounded-full">
                  <Plus className="h-4 w-4" />
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[400px] rounded-2xl">
                <DialogHeader>
                  <DialogTitle>Add New Category</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 mt-4">
                  <Input
                    placeholder="Category name"
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value)}
                    className="rounded-full"
                  />
                  <Button onClick={handleAddCategory} className="w-full rounded-full">
                    Add Category
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </div>

      <div className="space-y-2">
        <Popover>
          <PopoverTrigger asChild>
            <Button
              variant="outline"
              className={cn(
                "w-full justify-start text-left font-normal rounded-full",
                !dueDate && "text-muted-foreground",
              )}
            >
              <CalendarIcon className="mr-2 h-4 w-4" />
              {dueDate ? format(dueDate, "PPP") : <span>Pick a date</span>}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-0 rounded-xl">
            <Calendar mode="single" selected={dueDate} onSelect={(date) => date && setDueDate(date)} initialFocus />
          </PopoverContent>
        </Popover>
      </div>

      <div className="flex justify-end pt-2">
        <Button type="submit" className="btn-create">
          Create Task
        </Button>
      </div>
    </form>
  )
}
