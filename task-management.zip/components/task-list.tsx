"use client"

import { useState } from "react"
import type { Task, Priority, Category } from "@/types/task"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Card, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Trash2, Flag, Calendar, ChevronDown } from "lucide-react"
import { format } from "date-fns"
import { cn } from "@/lib/utils"

interface TaskListProps {
  tasks: Task[]
  onToggleCompletion: (id: string) => void
  onUpdatePriority: (id: string, priority: Priority) => void
  onDeleteTask: (id: string) => void
}

export function TaskList({ tasks, onToggleCompletion, onUpdatePriority, onDeleteTask }: TaskListProps) {
  const [filter, setFilter] = useState<{
    priority: Priority | "all"
    category: Category | "all"
  }>({
    priority: "all",
    category: "all",
  })

  const filteredTasks = tasks.filter((task) => {
    const priorityMatch = filter.priority === "all" || task.priority === filter.priority
    const categoryMatch = filter.category === "all" || task.category === filter.category
    return priorityMatch && categoryMatch
  })

  const categories = Array.from(new Set(tasks.map((task) => task.category))) as Category[]

  const getPriorityColor = (priority: Priority) => {
    switch (priority) {
      case "high":
        return "text-red-500"
      case "medium":
        return "text-amber-500"
      case "low":
        return "text-green-500"
      default:
        return ""
    }
  }

  const getCategoryColor = (category: Category) => {
    switch (category) {
      case "work":
        return "bg-blue-100 text-blue-800"
      case "personal":
        return "bg-purple-100 text-purple-800"
      case "health":
        return "bg-green-100 text-green-800"
      case "finance":
        return "bg-amber-100 text-amber-800"
      case "education":
        return "bg-indigo-100 text-indigo-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="flex-1">
          <Select
            value={filter.priority}
            onValueChange={(value) => setFilter({ ...filter, priority: value as Priority | "all" })}
          >
            <SelectTrigger>
              <SelectValue placeholder="Filter by priority" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Priorities</SelectItem>
              <SelectItem value="high">High Priority</SelectItem>
              <SelectItem value="medium">Medium Priority</SelectItem>
              <SelectItem value="low">Low Priority</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="flex-1">
          <Select
            value={filter.category}
            onValueChange={(value) => setFilter({ ...filter, category: value as Category | "all" })}
          >
            <SelectTrigger>
              <SelectValue placeholder="Filter by category" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              {categories.map((category) => (
                <SelectItem key={category} value={category}>
                  {category.charAt(0).toUpperCase() + category.slice(1)}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {filteredTasks.length === 0 ? (
        <div className="text-center py-10 text-muted-foreground">
          No tasks found. Try adjusting your filters or add a new task.
        </div>
      ) : (
        <div className="space-y-4">
          {filteredTasks.map((task) => (
            <Card key={task.id} className={cn("transition-all", task.completed && "opacity-60")}>
              <CardHeader className="pb-2">
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-2">
                    <Checkbox
                      id={`task-${task.id}`}
                      checked={task.completed}
                      onCheckedChange={() => onToggleCompletion(task.id)}
                      className="mt-1"
                    />
                    <div>
                      <CardTitle
                        className={cn("text-lg font-medium", task.completed && "line-through text-muted-foreground")}
                      >
                        {task.title}
                      </CardTitle>
                      <CardDescription className="mt-1">{task.description}</CardDescription>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className={getCategoryColor(task.category)}>
                      {task.category}
                    </Badge>
                    <Flag className={cn("h-4 w-4", getPriorityColor(task.priority))} fill="currentColor" />
                  </div>
                </div>
              </CardHeader>
              <CardFooter className="pt-2 flex justify-between">
                <div className="flex items-center text-sm text-muted-foreground">
                  <Calendar className="mr-1 h-4 w-4" />
                  {format(task.dueDate, "MMM d, yyyy")}
                </div>
                <div className="flex gap-2">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="outline" size="sm">
                        Priority <ChevronDown className="ml-1 h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => onUpdatePriority(task.id, "high")}>
                        <Flag className="mr-2 h-4 w-4 text-red-500" fill="currentColor" />
                        High
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => onUpdatePriority(task.id, "medium")}>
                        <Flag className="mr-2 h-4 w-4 text-amber-500" fill="currentColor" />
                        Medium
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => onUpdatePriority(task.id, "low")}>
                        <Flag className="mr-2 h-4 w-4 text-green-500" fill="currentColor" />
                        Low
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                  <Button variant="ghost" size="icon" onClick={() => onDeleteTask(task.id)}>
                    <Trash2 className="h-4 w-4" />
                    <span className="sr-only">Delete task</span>
                  </Button>
                </div>
              </CardFooter>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
