"use client"

import { useState } from "react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import { Calendar, Flag, Search, Plus } from "lucide-react"
import { format } from "date-fns"
import { cn } from "@/lib/utils"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { TaskForm } from "@/components/task-form"
import type { Task, Category } from "@/types/task"

export function TasksWithCategories() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCategory, setSelectedCategory] = useState<Category | "all">("all")
  const [isDialogOpen, setIsDialogOpen] = useState(false)

  // Sample tasks data
  const [tasks, setTasks] = useState<Task[]>([
    {
      id: "task-1",
      title: "Plan weekly grocery shopping",
      description: "Make a list of items needed for the week's meals",
      priority: "medium",
      category: "shopping",
      dueDate: new Date(Date.now() + 1 * 24 * 60 * 60 * 1000),
      completed: false,
      assignees: [],
      comments: 0,
    },
    {
      id: "task-2",
      title: "Schedule dentist appointment",
      description: "Call Dr. Smith's office for a checkup",
      priority: "low",
      category: "health",
      dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
      completed: false,
      assignees: [],
      comments: 0,
    },
    {
      id: "task-3",
      title: "Learn React hooks",
      description: "Complete the tutorial on useState and useEffect",
      priority: "high",
      category: "learning",
      dueDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000),
      completed: false,
      assignees: [],
      comments: 0,
    },
    {
      id: "task-4",
      title: "Organize home office",
      description: "Clean desk and organize cables",
      priority: "medium",
      category: "home",
      dueDate: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000),
      completed: true,
      assignees: [],
      comments: 0,
    },
    {
      id: "task-5",
      title: "Pay monthly bills",
      description: "Electricity, internet, and water bills",
      priority: "high",
      category: "finance",
      dueDate: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
      completed: true,
      assignees: [],
      comments: 0,
    },
    {
      id: "task-6",
      title: "Research vacation destinations",
      description: "Look into options for summer vacation",
      priority: "low",
      category: "personal",
      dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
      completed: false,
      assignees: [],
      comments: 0,
    },
    {
      id: "task-7",
      title: "Buy birthday gift for mom",
      description: "Look for that book she mentioned",
      priority: "medium",
      category: "personal",
      dueDate: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000),
      completed: false,
      assignees: [],
      comments: 0,
    },
  ])

  // Get unique categories
  const categories = Array.from(new Set(tasks.map((task) => task.category)))

  // Filter tasks based on search query and selected category
  const filteredTasks = tasks.filter((task) => {
    const matchesSearch =
      task.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      task.description.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesCategory = selectedCategory === "all" || task.category === selectedCategory
    return matchesSearch && matchesCategory
  })

  const handleAddTask = (task: Omit<Task, "id" | "assignees" | "comments" | "completed">) => {
    const newTask: Task = {
      ...task,
      id: `task-${Date.now()}`,
      assignees: [],
      comments: 0,
      completed: false,
    }

    setTasks([...tasks, newTask])
    setIsDialogOpen(false)
  }

  const toggleTaskCompletion = (id: string) => {
    setTasks(tasks.map((task) => (task.id === id ? { ...task, completed: !task.completed } : task)))
  }

  const getPriorityColor = (priority: Task["priority"]) => {
    switch (priority) {
      case "high":
        return "text-red-500"
      case "medium":
        return "text-amber-500"
      case "low":
        return "text-green-500"
      default:
        return ""
    }
  }

  const getCategoryColor = (category: Task["category"]) => {
    switch (category) {
      case "personal":
        return "bg-purple-100 text-purple-800 border-purple-200"
      case "work":
        return "bg-blue-100 text-blue-800 border-blue-200"
      case "health":
        return "bg-green-100 text-green-800 border-green-200"
      case "finance":
        return "bg-amber-100 text-amber-800 border-amber-200"
      case "learning":
        return "bg-indigo-100 text-indigo-800 border-indigo-200"
      case "home":
        return "bg-pink-100 text-pink-800 border-pink-200"
      case "shopping":
        return "bg-cyan-100 text-cyan-800 border-cyan-200"
      default:
        return "bg-gray-100 text-gray-800 border-gray-200"
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-center gap-4">
        <h1 className="text-2xl font-bold">Tasks by Category</h1>
        <div className="flex items-center gap-3 w-full md:w-auto">
          <div className="relative flex-1 md:w-64">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search tasks..."
              className="pl-10 rounded-full border-gray-200 focus:border-gray-300 focus:ring-gray-300"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button className="btn-create flex-shrink-0">
                <Plus className="h-4 w-4 mr-2" />
                New Task
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[500px] rounded-2xl">
              <DialogHeader>
                <DialogTitle>Create New Task</DialogTitle>
              </DialogHeader>
              <TaskForm onAddTask={handleAddTask} />
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <Tabs defaultValue="all" onValueChange={(value) => setSelectedCategory(value as Category | "all")}>
        <TabsList className="bg-muted/50 p-1 rounded-full">
          <TabsTrigger value="all" className="rounded-full data-[state=active]:bg-white">
            All
          </TabsTrigger>
          {categories.map((category) => (
            <TabsTrigger key={category} value={category} className="rounded-full data-[state=active]:bg-white">
              {category.charAt(0).toUpperCase() + category.slice(1)}
            </TabsTrigger>
          ))}
        </TabsList>

        <div className="mt-6 space-y-4">
          {filteredTasks.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              No tasks found. Try adjusting your search or filters.
            </div>
          ) : (
            filteredTasks.map((task) => (
              <Card key={task.id} className="task-card">
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    <Checkbox
                      id={`task-${task.id}`}
                      checked={task.completed}
                      onCheckedChange={() => toggleTaskCompletion(task.id)}
                      className="mt-1"
                    />
                    <div className="flex-1">
                      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-2 mb-2">
                        <div>
                          <h3 className={cn("font-medium", task.completed && "line-through text-muted-foreground")}>
                            {task.title}
                          </h3>
                          <p className="text-sm text-muted-foreground mt-1">{task.description}</p>
                        </div>
                        <div className="flex items-center gap-2 flex-shrink-0">
                          <Badge
                            variant="outline"
                            className={cn("text-xs font-medium rounded-full", getCategoryColor(task.category))}
                          >
                            {task.category.charAt(0).toUpperCase() + task.category.slice(1)}
                          </Badge>
                          <Flag className={cn("h-4 w-4", getPriorityColor(task.priority))} fill="currentColor" />
                        </div>
                      </div>

                      <div className="flex items-center justify-end mt-3">
                        <div className="flex items-center text-muted-foreground">
                          <Calendar className="h-3 w-3 mr-1" />
                          <span className="text-xs">{format(task.dueDate, "MMM d, yyyy")}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </Tabs>
    </div>
  )
}
