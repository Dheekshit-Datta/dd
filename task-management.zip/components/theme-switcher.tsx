"use client"

import { Check } from "lucide-react"
import { cn } from "@/lib/utils"
import { useTheme } from "@/contexts/theme-context"

export function ThemeSwitcher() {
  const { theme, setTheme } = useTheme()

  const themes = [
    {
      name: "Minimal",
      value: "minimal",
      primaryColor: "bg-black",
      secondaryColor: "bg-gray-200",
      accentColor: "bg-gray-800",
    },
    {
      name: "Colorful",
      value: "colorful",
      primaryColor: "bg-blue-600",
      secondaryColor: "bg-blue-100",
      accentColor: "bg-yellow-400",
    },
    {
      name: "Pastel",
      value: "pastel",
      primaryColor: "bg-pink-400",
      secondaryColor: "bg-yellow-100",
      accentColor: "bg-teal-300",
    },
  ]

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-medium">Choose Theme</h3>
      <div className="grid grid-cols-3 gap-4">
        {themes.map((t) => (
          <div key={t.value} onClick={() => setTheme(t.value as any)} className="cursor-pointer">
            <div className={cn("theme-card", theme === t.value && "active")}>
              <div className="theme-preview">
                <div className={cn("theme-preview-header", t.primaryColor)}>
                  {theme === t.value && (
                    <div className="ml-auto mr-1">
                      <Check className="h-4 w-4 text-white" />
                    </div>
                  )}
                </div>
                <div className="theme-preview-content">
                  <div className={cn("theme-preview-sidebar", t.secondaryColor)}></div>
                  <div className="theme-preview-main">
                    <div className={cn("theme-preview-card", t.secondaryColor)}></div>
                    <div className={cn("theme-preview-card", t.secondaryColor)}></div>
                    <div className={cn("theme-preview-card", t.accentColor)}></div>
                  </div>
                </div>
              </div>
            </div>
            <p className="mt-1 text-center text-sm">{t.name}</p>
          </div>
        ))}
      </div>
    </div>
  )
}
