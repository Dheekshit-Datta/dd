"use client"

import type React from "react"

import { createContext, useContext, useEffect, useState } from "react"

type Theme = "minimal" | "colorful" | "pastel"

type ThemeProviderProps = {
  children: React.ReactNode
}

type ThemeContextType = {
  theme: Theme
  setTheme: (theme: Theme) => void
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined)

export function ThemeProvider({ children }: ThemeProviderProps) {
  const [theme, setTheme] = useState<Theme>("minimal")

  useEffect(() => {
    // Apply theme class to document
    document.documentElement.classList.remove("theme-minimal", "theme-colorful", "theme-pastel")
    document.documentElement.classList.add(`theme-${theme}`)

    // Save theme preference
    localStorage.setItem("theme", theme)
  }, [theme])

  useEffect(() => {
    // Load saved theme on initial render
    const savedTheme = localStorage.getItem("theme") as Theme | null
    if (savedTheme) {
      setTheme(savedTheme)
    }
  }, [])

  return <ThemeContext.Provider value={{ theme, setTheme }}>{children}</ThemeContext.Provider>
}

export function useTheme() {
  const context = useContext(ThemeContext)
  if (context === undefined) {
    throw new Error("useTheme must be used within a ThemeProvider")
  }
  return context
}
