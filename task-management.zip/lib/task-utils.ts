import type { Category } from "@/types/task"

// Keywords for automatic categorization
const categoryKeywords: Record<string, string[]> = {
  personal: ["personal", "family", "friend", "social", "hobby", "vacation", "travel", "gift", "birthday", "holiday"],
  work: ["work", "job", "career", "meeting", "project", "client", "email", "report", "presentation", "deadline"],
  health: [
    "health",
    "doctor",
    "dentist",
    "appointment",
    "medicine",
    "exercise",
    "workout",
    "fitness",
    "diet",
    "nutrition",
  ],
  finance: ["finance", "money", "bill", "payment", "budget", "tax", "invest", "bank", "insurance", "expense"],
  learning: ["learning", "study", "course", "class", "book", "read", "tutorial", "skill", "education", "knowledge"],
  home: ["home", "house", "apartment", "clean", "organize", "repair", "maintenance", "decorate", "furniture", "garden"],
  shopping: ["shopping", "grocery", "store", "buy", "purchase", "order", "delivery", "online", "mall", "market"],
  other: [],
}

export function categorizeTask(title: string, description: string): Category {
  const text = `${title} ${description}`.toLowerCase()

  // Check each category's keywords
  for (const [category, keywords] of Object.entries(categoryKeywords)) {
    if (category === "other") continue

    for (const keyword of keywords) {
      if (text.includes(keyword.toLowerCase())) {
        return category as Category
      }
    }
  }

  // Default to "personal" if no match found
  return "personal"
}
