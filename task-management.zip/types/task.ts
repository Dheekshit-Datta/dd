export type Priority = "high" | "medium" | "low"
export type Category = "personal" | "work" | "health" | "finance" | "learning" | "home" | "shopping" | string // Allow for custom categories

export interface User {
  id: string
  name: string
  image: string
}

export interface Task {
  id: string
  title: string
  description: string
  priority: Priority
  category: Category
  dueDate: Date
  completed: boolean
  assignees: User[]
  comments: number
}

export interface Column {
  id: string
  title: string
  color: string
  tasks: Task[]
}
